import './App.css';
import React, { useEffect, useState } from "react";
import axios from "axios";
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import FilterListIcon from '@mui/icons-material/FilterList';
import EmailIcon from '@mui/icons-material/Email';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import Modal from '@mui/material/Modal';
import { Button } from '@mui/material';
import * as moment from 'moment';
import "react-datepicker/dist/react-datepicker.css";
import DatePicker from "react-datepicker";

import 'date-fns';

const App = () => {
    const [restaurantObject, setRestaurantObject] = useState(null);
    const [orderObject, setOrderObject] = useState([]);
    const [fileteredOrderObject, setFileteredOrderObject] = useState([]);
    const [startDate, setStartDate] = useState(new Date());
    const [accessToken, setAccessToken] = useState(null);
    const [open, setOpen] = React.useState(false);


    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const filterBuckets = (key) => {
        handleClose()
        setFileteredOrderObject(orderObject.filter((order) => buckets[key].includes(order.stage_id)))
        console.log(restaurantObject)
    }

    let status = "";
    let status_class = "";

    const buckets = { 'New Orders': ["1"], 'Preparing': ["2", "3"], 'Out for Delivery': ["4", "5", "6"], 'Completed Orders': ["7", "8", "9"] }
    useEffect(()=>{
        const token=localStorage.getItem('accessToken');
        if(token){
            setAccessToken(token);
        }
    },[])
    const fetchAxiosCall = () => {
        console.log("hi",restaurantObject)
        localStorage.setItem("accessToken",accessToken);
        setAccessToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NywiaWF0IjoxNjMzNTk5NTgwLCJleHAiOjE2MzM2ODU5ODB9.VJP6OlOb-nNjEez3PQkImcvukY3Z2uBNsPmAwBD5hig")


    };
    useEffect(() => {
        const baseURL = "https://testingapi.smartdiner.co/";
        const restaurant_fetch = "after_login/restaurant/get_details";
        const order_fetch = "after_login/restaurant/2/get_orders";
        const config = {
            headers: {
                'x-access-token': accessToken
            }
        }

        axios.get(baseURL + order_fetch, config).then((response) => {
            setOrderObject(response.data.orders);
            setFileteredOrderObject(response.data.orders);
            localStorage.setItem('restaurantSession', JSON.stringify({ orderObj: response.data.orders }))
        }).catch(function (error) {
            if (error.response.status === 401) {
                const orderObj = JSON.parse(localStorage.getItem('restaurantSession'));
                console.log(orderObj)
                if (orderObj && Object.keys(orderObj).length > 0) {
                    setOrderObject(orderObj.orderObj);
                    setFileteredOrderObject(orderObj.orderObj);
                }
                else {
                    window.alert("Session expired. Need a JWT token")
                }
            }
        });
        axios.get(baseURL + restaurant_fetch, config).then((response) => {
            console.log(response)
            setRestaurantObject(response.data.restaurantEmployee)
            let sessionObj = JSON.parse(localStorage.getItem('restaurantSession'))
            localStorage.setItem('restaurantSession', JSON.stringify({ ...sessionObj, restaurantObj: response.data.restaurantEmployee }))

        }).catch(function (error) {
            if (error.response.status === 401) {
                const restaurantObj = JSON.parse(localStorage.getItem('restaurantSession'));

                if (restaurantObj && Object.keys(restaurantObj).length > 0) {
                    setRestaurantObject(restaurantObj.restaurantObj);
                    console.log(error.response.status)
                }
                else {
                    window.alert("Session expired. Need a JWT token")
                }

            }
        });
    }, [accessToken]);

    return (<div className="restaurant_container" >
        {!accessToken ? <div style={{ display: 'flex', flex: 1, justifyContent: 'center' }}>
            <Button onClick={() => fetchAxiosCall()}>Sign In</Button>
        </div>
            :
            restaurantObject && <div>
                <div style={{ backgroundImage: "url(" + restaurantObject.restaurant_branch.restaurant.logo + ")", height: '200px', backgroundSize: 'cover', opacity: 0.3 }}>
                </div>
                <div style={{ position: 'absolute', top: '20px', left: '10px' }}>
                    <div style={{ display: 'flex' }}>
                        <Typography sx={{ fontSize: 24, fontWeight: 'bold', color: "#fff", flex: 1 }} color="text.primary" gutterBottom>
                            {restaurantObject.customer.name}
                        </Typography>
                        <Button style={{ backgroundColor: 'skyblue' }} onClick={() => {
                            setAccessToken(null)
                            setOrderObject([]);
                            setFileteredOrderObject([]);
                            setRestaurantObject(null);
                            localStorage.removeItem('restaurantSession');
                            window.alert("Session expired. Need a JWT token")
                        }}>
                            Logout
                        </Button>
                    </div>
                    <div style={{ display: "flex", marginTop: '10px' }}>
                        <EmailIcon style={{ color: "#fff" }} />
                        <Typography sx={{ fontSize: 14, fontWeight: 'bold', paddingLeft: '10px', color: '#fff' }} color="text.secondary" gutterBottom>
                            {restaurantObject.customer.email}
                        </Typography>
                    </div>
                    <div style={{ display: "flex", marginTop: '10px' }}>
                        <LocationOnIcon style={{ color: "#fff" }} />
                        <Typography sx={{ fontSize: 14, fontWeight: 'bold', paddingLeft: '10px', color: "#fff" }} color="text.secondary" gutterBottom>
                            {restaurantObject.restaurant_branch.address}
                        </Typography>
                    </div>
                    <div style={{ display: "flex", marginTop: '10px' }}>
                        <AccessTimeIcon style={{ color: "#fff" }} />
                        <Typography sx={{ fontSize: 14, fontWeight: 'bold', paddingLeft: '10px', color: '#fff' }} color="text.secondary" gutterBottom>
                            {restaurantObject.restaurant_branch.timings}
                        </Typography>
                    </div>
                </div>
            </div>}
        {
            accessToken &&
            <div>
                <div style={{ 'flex': 1, display: 'flex', alignItems: 'center', margin: '50px' }}>
                    <h4 style={{ flex: 1 }}>Orders</h4>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                        <DatePicker selected={startDate} onChange={(date) => {
                            setStartDate(date);
                            setFileteredOrderObject(orderObject.filter(orders => moment(orders.createdAt).format("YYYY-MM-DD") === moment(date).format("YYYY-MM-DD")))
                        }
                        } />
                        <FilterListIcon onClick={handleOpen} />
                        <Button onClick={() => setFileteredOrderObject(orderObject)}>Reset</Button>
                        <Modal
                            style={{
                                height: 'fit-content', left: 'inherit', top: '120px', right: '20px', backgroundColor: "#fff",
                                boxShadow: "2px 4px #888888",
                                borderRadius: "10px",
                                padding: "10px"
                            }}
                            open={open}
                            transparent={true}
                            onClose={handleClose}
                            aria-labelledby="modal-modal-title"
                            aria-describedby="modal-modal-description"
                        >
                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'baseline' }}>
                                {Object.keys(buckets).map(key => {
                                    return <Button onClick={() => { filterBuckets(key) }}>
                                        {key}
                                    </Button>
                                })}
                            </div>
                        </Modal>
                    </div>
                </div>
                {fileteredOrderObject.map((orders) => {
                    return (<div style={{ margin: '50px' }}><Card sx={{ minWidth: 275 }}>
                        <CardContent>
                            <div >
                                {Object.entries(buckets).forEach((value) => {
                                    if (value[1].includes(orders.stage_id)) {

                                        status = value[0]
                                        status_class = value[0].replaceAll(" ", "_").toLowerCase()

                                    }
                                })}
                                <Typography className={status_class} sx={{ fontSize: 14 }} gutterBottom>
                                    {status}
                                </Typography>
                            </div>
                            <div style={{ display: 'flex' }}>
                                <div className="order_details">

                                    <Typography sx={{ fontSize: 14, fontWeight: 'bold' }} color="text.secondary" gutterBottom>
                                        Order Id
                                    </Typography>
                                    <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                        {orders.id}
                                    </Typography>
                                </div>
                                <div className="order_details">

                                    <Typography sx={{ fontSize: 14, fontWeight: 'bold' }} color="text.secondary" gutterBottom>
                                        Stage Id
                                    </Typography>
                                    <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                        {orders.stage_id}
                                    </Typography>
                                </div>
                                <div className="order_details">

                                    <Typography sx={{ fontSize: 14, fontWeight: 'bold' }} color="text.secondary" gutterBottom>
                                        Payment Status Id
                                    </Typography>
                                    <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                        {orders.payment_status_id}
                                    </Typography>
                                </div>
                            </div>
                            <Typography sx={{ fontSize: 14, fontWeight: 'bold' }} color="text.secondary" gutterBottom>
                                Delivery Address
                            </Typography>
                            <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                {orders.delivery_address_one},{orders.delivery_address_two}
                            </Typography>
                            <Typography sx={{ fontSize: 14, fontWeight: 'bold' }} color="text.secondary" gutterBottom>
                                PRICE
                            </Typography>
                            <div className="price">
                                <Typography className="price_key" sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                    total mrp
                                </Typography>
                                <Typography className="price_value" style={{ paddingLeft: '40px' }} sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                    &#x20B9;{orders.total_mrp_price}
                                </Typography>
                            </div>
                            <div className="price">
                                <Typography className="price_key" sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                    delivery charge
                                </Typography>
                                <Typography className="price_value" style={{ paddingLeft: '40px' }} sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                    &#x20B9;{orders.delivery_charge}
                                </Typography>
                            </div>
                            <div className="price">
                                <Typography className="price_key" sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                    total
                                </Typography>
                                <Typography className="price_value" style={{ paddingLeft: '40px' }} sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                    &#x20B9;{orders.total_price}
                                </Typography>
                            </div>
                            <Typography sx={{ fontSize: 14, fontWeight: 'bold' }} color="text.secondary" gutterBottom>
                                Created Date
                            </Typography>
                            <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                                {moment(orders.createdAt).format("YYYY-MM-DD HH:mm:ss")}
                            </Typography>
                        </CardContent>
                    </Card>
                    </div>)
                })}
            </div>
        }
    </div >
    );
}

export default App;